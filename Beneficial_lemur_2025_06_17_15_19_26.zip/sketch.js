// Dimensões do canteiro
const CANTEIRO_LARGURA = 80;
const CANTEIRO_ALTURA = 80;

// Estados do canteiro
const VAZIO = 0;
const CAVADO = 1;
const SEMENTE_PLANTADA = 2;
const SEMENTE_REGADA = 3;
const PLANTA_CRESCIDA = 4; // Pronto para colher

// Classe para representar um canteiro
class Canteiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.estado = VAZIO;
    this.tempoCrescimento = 0; // Para controlar o crescimento da planta
    this.tempoRegado = 0; // Para controlar quanto tempo a planta está regada
  }

  // Desenha o canteiro na tela de acordo com seu estado
  display() {
    push();
    translate(this.x, this.y);

    switch (this.estado) {
      case VAZIO:
        fill(139, 69, 19); // Cor de terra
        rect(0, 0, CANTEIRO_LARGURA, CANTEIRO_ALTURA);
        fill(255); // Texto
        textSize(12);
        textAlign(CENTER, CENTER);
        text("Vazio", CANTEIRO_LARGURA / 2, CANTEIRO_ALTURA / 2);
        break;
      case CAVADO:
        fill(100, 50, 0); // Cor de terra mais escura (cavada)
        rect(0, 0, CANTEIRO_LARGURA, CANTEIRO_ALTURA);
        fill(255);
        textSize(12);
        textAlign(CENTER, CENTER);
        text("Cavado", CANTEIRO_LARGURA / 2, CANTEIRO_ALTURA / 2);
        break;
      case SEMENTE_PLANTADA:
        fill(100, 50, 0); // Terra cavada
        rect(0, 0, CANTEIRO_LARGURA, CANTEIRO_ALTURA);
        fill(0, 100, 0); // Semente (pequeno círculo)
        ellipse(CANTEIRO_LARGURA / 2, CANTEIRO_ALTURA / 2, 10, 10);
        fill(255);
        textSize(12);
        textAlign(CENTER, CENTER);
        text("Semente", CANTEIRO_LARGURA / 2, CANTEIRO_ALTURA / 2 + 20);
        break;
      case SEMENTE_REGADA:
        fill(100, 50, 0); // Terra cavada
        rect(0, 0, CANTEIRO_LARGURA, CANTEIRO_ALTURA);
        fill(0, 150, 0); // Planta pequena
        rect(CANTEIRO_LARGURA / 2 - 2, CANTEIRO_ALTURA / 2 + 10, 4, 15); // Caule
        ellipse(CANTEIRO_LARGURA / 2, CANTEIRO_ALTURA / 2, 15, 15); // Folha/broto
        fill(0, 0, 200, 100); // Gota de água
        ellipse(CANTEIRO_LARGURA - 15, 15, 10, 10);
        fill(255);
        textSize(12);
        textAlign(CENTER, CENTER);
        text("Regada", CANTEIRO_LARGURA / 2, CANTEIRO_ALTURA / 2 + 20);
        break;
      case PLANTA_CRESCIDA:
        fill(100, 50, 0); // Terra cavada
        rect(0, 0, CANTEIRO_LARGURA, CANTEIRO_ALTURA);
        fill(0, 200, 0); // Planta crescida (maior)
        rect(CANTEIRO_LARGURA / 2 - 5, CANTEIRO_ALTURA / 2, 10, 30); // Caule maior
        ellipse(CANTEIRO_LARGURA / 2, CANTEIRO_ALTURA / 2 - 15, 40, 40); // Folhas grandes
        fill(255, 0, 0); // Fruto (ex: uma maçã)
        ellipse(CANTEIRO_LARGURA / 2 + 15, CANTEIRO_ALTURA / 2 - 25, 15, 15);
        fill(255);
        textSize(12);
        textAlign(CENTER, CENTER);
        text("Colher!", CANTEIRO_LARGURA / 2, CANTEIRO_ALTURA / 2 + 30);
        break;
    }
    pop();
  }

  // Atualiza o estado do canteiro (ex: crescimento da planta)
  update() {
    if (this.estado === SEMENTE_REGADA) {
      this.tempoRegado += deltaTime / 1000; // Soma o tempo em segundos
      if (this.tempoRegado >= 5) { // Planta cresce após 5 segundos regada
        this.estado = PLANTA_CRESCIDA;
        this.tempoRegado = 0; // Reseta para próxima regada, se houver
      }
    }
  }

  // Verifica se o mouse está sobre este canteiro
  contains(px, py) {
    return px > this.x && px < this.x + CANTEIRO_LARGURA &&
           py > this.y && py < this.y + CANTEIRO_ALTURA;
  }

  // Interage com o canteiro (passa para o próximo estado)
  interagir() {
    switch (this.estado) {
      case VAZIO:
        this.estado = CAVADO;
        print("Canteiro cavado!");
        break;
      case CAVADO:
        this.estado = SEMENTE_PLANTADA;
        print("Semente plantada!");
        break;
      case SEMENTE_PLANTADA:
        this.estado = SEMENTE_REGADA;
        this.tempoRegado = 0; // Reinicia o tempo para o crescimento
        print("Semente regada!");
        break;
      case PLANTA_CRESCIDA:
        this.estado = VAZIO; // Colhe e o canteiro volta a ser vazio
        print("Planta colhida!");
        // Aqui você adicionaria pontos ao jogador, itens ao inventário, etc.
        break;
    }
  }
}

// Lista de canteiros
let canteiros = [];

// Ferramenta atualmente selecionada
let ferramentaAtual = "Nenhuma"; // Pode ser "Pá", "Semente", "Regador"

function setup() {
  createCanvas(600, 400);
  rectMode(CORNER); // Desenha retângulos a partir do canto superior esquerdo

  // Cria alguns canteiros
  canteiros.push(new Canteiro(50, 50));
  canteiros.push(new Canteiro(150, 50));
  canteiros.push(new Canteiro(250, 50));
  canteiros.push(new Canteiro(50, 150));
  canteiros.push(new Canteiro(150, 150));
}

function draw() {
  background(100, 150, 50); // Fundo verde (grama)

  // Desenha todos os canteiros e os atualiza
  for (let canteiro of canteiros) {
    canteiro.display();
    canteiro.update();
  }

  // Desenha a interface do usuário (ferramentas)
  drawUI();

  // Exibe a ferramenta atual
  fill(0);
  textSize(16);
  text(`Ferramenta: ${ferramentaAtual}`, 10, height - 10);
}

// Função para desenhar a interface do usuário
function drawUI() {
  fill(200);
  rect(0, height - 50, width, 50); // Barra de ferramentas na parte inferior

  // Botões das ferramentas
  fill(255);
  stroke(0);

  // Pá
  rect(10, height - 40, 60, 30);
  fill(0);
  textSize(14);
  textAlign(CENTER, CENTER);
  text("Pá", 40, height - 25);

  // Semente
  fill(255);
  rect(80, height - 40, 60, 30);
  fill(0);
  text("Semente", 110, height - 25);

  // Regador
  fill(255);
  rect(150, height - 40, 60, 30);
  fill(0);
  text("Regador", 180, height - 25);

  // Mão (Colher)
  fill(255);
  rect(220, height - 40, 60, 30);
  fill(0);
  text("Mão", 250, height - 25);
}


// Gerencia cliques do mouse
function mousePressed() {
  // Clicou nos botões de ferramenta?
  if (mouseX > 10 && mouseX < 70 && mouseY > height - 40 && mouseY < height - 10) {
    ferramentaAtual = "Pá";
    print("Ferramenta Pá selecionada!");
  } else if (mouseX > 80 && mouseX < 140 && mouseY > height - 40 && mouseY < height - 10) {
    ferramentaAtual = "Semente";
    print("Ferramenta Semente selecionada!");
  } else if (mouseX > 150 && mouseX < 210 && mouseY > height - 40 && mouseY < height - 10) {
    ferramentaAtual = "Regador";
    print("Ferramenta Regador selecionada!");
  } else if (mouseX > 220 && mouseX < 280 && mouseY > height - 40 && mouseY < height - 10) {
    ferramentaAtual = "Mão";
    print("Ferramenta Mão selecionada!");
  } else {
    // Se não clicou nos botões, verifica se clicou em um canteiro
    for (let canteiro of canteiros) {
      if (canteiro.contains(mouseX, mouseY)) {
        // Aplica a interação baseada na ferramenta atual e no estado do canteiro
        interagirComCanteiro(canteiro);
        break; // Interagiu com um canteiro, pode parar de procurar
      }
    }
  }
}

// Lógica de interação específica com o canteiro
function interagirComCanteiro(canteiro) {
  switch (ferramentaAtual) {
    case "Pá":
      if (canteiro.estado === VAZIO) {
        canteiro.interagir(); // Cavar
      } else {
        print("Não posso usar a pá aqui. O canteiro não está vazio.");
      }
      break;
    case "Semente":
      if (canteiro.estado === CAVADO) {
        canteiro.interagir(); // Plantar
      } else {
        print("Não posso plantar. O canteiro não está cavado.");
      }
      break;
    case "Regador":
      if (canteiro.estado === SEMENTE_PLANTADA) {
        canteiro.interagir(); // Regar
      } else {
        print("Não preciso regar agora. A planta não está na fase correta.");
      }
      break;
    case "Mão":
      if (canteiro.estado === PLANTA_CRESCIDA) {
        canteiro.interagir(); // Colher
      } else {
        print("Não há nada para colher.");
      }
      break;
    default:
      print("Selecione uma ferramenta!");
      break;
  }
}